import{d as o,u as n,_,o as s,c as r,p as c,g as p,a as u,j as d}from"./index.5721b27d.js";const l=o({name:"About",setup(){console.log("got setup");const e=n();return console.log(`levelText: ${e.levelText}
level: ${e.level}
sorted_bookmarks: ${JSON.stringify(e.sorted_bookmarks)}
shown_bookmarks: ${JSON.stringify(e.shown_bookmarks)}
unknown_shown: ${e.unknown_shown}`),{store:e}},data(){return{}}}),i=e=>(c("data-v-49dbc646"),e=e(),p(),e),h={class:"about"},k=i(()=>u("h1",null,"This is an about page.",-1)),b=[k];function m(e,t,a,f,$,g){return s(),r("div",h,b)}var v=_(l,[["render",m],["__scopeId","data-v-49dbc646"]]);const x=o({setup(e){return(t,a)=>(s(),d(v))}});export{x as default};
